﻿using System;

namespace c_
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Sang(1) , kaqaz(2) , qeychi(3) ?");
            int user = int.Parse(Console.ReadLine());

            // Create Random Test
            Random test = new Random();
            int robot = test.Next(1 , 3);

            Console.WriteLine("\n ------------------------------------ \n");

            if (user == 1 && robot == 1)
            {
                Console.WriteLine("Equal - (User:sang & robot:sang)");
            }else if(user == 1 && robot == 2){
                Console.WriteLine("You Lost - (User:sang & robot:kaqaz)");
            }else if(user == 1 && robot == 3){
                Console.WriteLine("You Win - (User:sang & robot:qeychi)");
            }else if(user == 2 && robot == 1){
                Console.WriteLine("You Win - (User:kaqaz & robot:sang)");
            }else if(user == 2 && robot == 2){
                Console.WriteLine("Equal - (User:kaqaz & robot:kaqaz)");
            }else if(user == 2 && robot == 3){
                Console.WriteLine("You Lost - (User:kaqaz & robot:qeychi)");
            }else if(user == 3 && robot == 1){
                Console.WriteLine("You Lost - (User:qeychi & robot:sang)");
            }else if(user == 3 && robot == 2){
                Console.WriteLine("You Win - (User:qeychi & robot:kaqaz)");
            }else{
                Console.WriteLine("Equal - (User:qeychi & robot:qeychi)");
            }

            Console.WriteLine("\n \a");
        }
    }
}
